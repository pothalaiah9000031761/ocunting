export class customermodel {
    // customerId: string;
    firstName: string; 
    lastName: string;
    email: string; 
    company: string;
    phone: string;
    fax: string; 
    displayNameAs: string;
    gstRegistrationType: string;
    taxInfo: string;
    taxInfoNo: string;
    address: string;
    city: string;
    state: string; 
    pincode: string;
    notes: string;
    // description: string;
}