export class chartofaccountsmodel {
    accountTypeName: string;
}