export class costcentermodel {
    costCenterName: string;
    costCenterCode: string;
    phoneNumber: string; 
    address: string;
}