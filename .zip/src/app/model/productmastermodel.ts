export class productmastermodel {
    // productId: number;
    productName: string;
    description: string; 
    hsnCode: number;
    taxRates: number;
    sellingPrice: number;
    buyingPrice: number;
    dateOfSelling: Date;
    dateOfBuying: Date;
    costCenters: string;
    productDescription: string;
}
