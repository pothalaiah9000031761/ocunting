import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateall-vendors',
  templateUrl: './updateall-vendors.component.html',
  styleUrls: ['./updateall-vendors.component.css']
})
export class UpdateallVendorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
