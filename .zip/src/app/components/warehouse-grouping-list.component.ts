import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warehouse-grouping',
  templateUrl: './warehouse-grouping-list.component.html',
  styles: [
  ]
})
export class WarehouseGroupingListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
