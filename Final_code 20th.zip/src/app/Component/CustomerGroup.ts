export class CustomerGroup
{
groupId:number
groupName: string;
customers: any=[];
}