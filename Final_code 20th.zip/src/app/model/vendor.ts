export interface Vendor {
    creditLimit: string,
   
}
